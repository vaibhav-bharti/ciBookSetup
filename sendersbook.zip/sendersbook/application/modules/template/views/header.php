<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html class="hide-sidebar ls-bottom-footer" lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="">
<title>SENDERSBOOK</title>
<link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" href="<?php  echo base_url();?>/assets/css/bootstrap.css">
<script src="<?php  echo base_url();?>assets/js/jquery.min.js"></script>
<script src="<?php  echo base_url();?>assets/js/jquery.validate.js"></script>
<!-- App CSS CORE
This variant is to be used when loading the separate styling modules -->
<link href="<?php  echo base_url();?>/assets/css/main.css" rel="stylesheet">




<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body class="login">
<div id="content">
  <header>
  <div class="container-fluid">
    <div class="navbar navbar-main navbar-primary navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header">
		<a class="navbar-brand" href="index.html"><img class="img-reponsive" src="<?php  echo base_url();?>/assets/images/logo-main.png"> </a> 
		 <button class="navbar-toggle" type="button" data-toggle="collapse"  data-target="#myDefaultNavbar1" aria-expanded="false"> <span class="s-only text"> <i class="fa fa-sign-in" aria-hidden="true"></i>
</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>  </button>
		</div>
		
	<div id="flash-message">	
	
    </div>
	
        <div class="navbar-collapse collapse" id="myDefaultNavbar1">
        <!-- Collect the nav links, forms, and other content for toggling -->
		<?php
			$login = array(
				'name'	=> 'login',
				'id'	=> 'login',
				'value' => set_value('login'),
				'maxlength'	=> 80,
				'size'	=> 30,
			);
			
				$login_label = 'Email';
			
			$password = array(
				'name'	=> 'password',
				'id'	=> 'password',
				'size'	=> 30,
			);
			$remember = array(
				'name'	=> 'remember',
				'id'	=> 'remember',
				'value'	=> 1,
				'checked'	=> set_value('remember'),
				'style' => 'margin:0;padding:0',
			);
			$captcha = array(
				'name'	=> 'captcha',
				'id'	=> 'captcha',
				'maxlength'	=> 8,
			);
			?>
        <div  class="login-form">
		 <form  id="loginform" name="loginform" action="<?php echo base_url(); ?>home/login" autocomplete="off" method="POST">
		 <?php echo form_open($this->uri->uri_string()); ?>
          <ul class="nav navbar-nav  navbar-right">
		    
            <li>
              <div  class="input-group"> <span class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></span>
                <input id="login-username" type="email" class="form-control" name="login" value="" placeholder="Email">
				
              </div>
			 
			  <span class="my-login-error-class" style="color:#cc99ff"> <?php echo form_error($login['name']); ?><?php echo isset($errors[$login['name']])?$errors[$login['name']]:''; ?></span>
              <a href="forgotpassword.html" style=" margin-top:5px;" class="forgot-password">Forgot password?</a> </li>
            <li>
              <div  class="input-group"> <span class="input-group-addon"><i class="fa fa-lock" aria-hidden="true"></i></span>
                <input id="login-password" type="password" class="form-control" name="password" placeholder="Password">
              </div>
                 <span class="my-login-error-class" style="color:#cc99ff"><?php echo form_error($password['name']); ?><?php echo isset($errors[$password['name']])?$errors[$password['name']]:''; ?></span>
                                      <div style=" margin-top:5px;" class="remember-me" >
                                        <label>
                                          <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                                        </label>
                                      </div>
                                
            </li>
            <li>
              <div class="form-group"> 
                <!-- Button -->
                
                <div class="controls"> <p><button class="btn login-button" type="submit">Log IN</button></p></div>
              </div>
            </li>
            
            <!-- User -->      
          </ul>
		  </form>
        </div>
		</div>
        <!-- /.navbar-collapse --> 
      </div>
    </div>
  </div>
  </header>
  
  