<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html class="hide-sidebar ls-bottom-footer" lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="author" content="">
<title>SENDERSBOOK</title>



<!--   -->
<link rel="stylesheet" href="<?php  echo base_url();?>/assets/css/bootstrap.min.css">
<link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet">

  <link href="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css" rel="stylesheet">

			
<!--   -->
<script>
	var baseUrl="<?php echo base_url(); ?>";
</script>

<!-- App CSS CORE
This variant is to be used when loading the separate styling modules -->
<link href="<?php echo base_url(); ?>/assets/css/main.css" rel="stylesheet">
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body class="innerpages">
<div id="content">
  <div class="container-fluid">
    <div class="navbar navbar-main navbar-primary navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header"> 
		
		<a class="navbar-brand" href="index.html"><img src="<?php echo base_url(); ?>/assets/images/logo-main.png"> </a>

 <button class="navbar-toggle inner-pages" type="button" data-toggle="collapse"  data-target="#myDefaultNavbar1" aria-expanded="false"> <span class="sr-only">
</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>  </button>
		</div>
        <div id="flash-message">	
	
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
		   <div class="navbar-collapse collapse" id="myDefaultNavbar1">
        <div id="main-nav" class="headerbar" >
       <ul class="nav navbar-nav  navbar-right ">
            
            <!-- User -->
    <li>
             <a href="<?=base_url() ?>home/myprofile" class="user">
                <img src="<?php echo base_url(); ?>/assets/images/user-small.jpg" alt="Username" class="img-rounded img-responsive" width="30">  <span> Username  </span>
              </a>
             
            </li>
			<li> <a href="<?=base_url() ?>home/postpage" class="posts">Posts
               
              </a> </li>
			  <li> <a href="notification.html" class="notifications-top-icon">
               <i class="fa fa-bell" aria-hidden="true"></i>
              </a> 
</li>
			  <li> <a href="setting.html" class="top-account-setting">
               <i class="fa fa-cog" aria-hidden="true"></i>
              </a> 
</li>
			  <li> <a href="<?=base_url() ?>home/logout" class="logout">
               <i class="fa fa-power-off" aria-hidden="true"></i>
              </a> 
</li>

          </ul>
        </div>
		</div>
        <!-- /.navbar-collapse --> 
      </div>
    </div>
  </div>
 