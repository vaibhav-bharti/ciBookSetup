<div style="display:block;height:5em;" ></div>
</div>
<!-- Footer -->
<footer class="footer"> <strong>SENDERSBOOK</strong> v4.0.0 &copy; Copyright 2017 </footer>
<!-- // Footer --> 
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php  echo base_url();?>assets/js/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script>
 <script src="//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/src/js/bootstrap-datetimepicker.js"></script>
<script src="<?php  echo base_url();?>assets/js/jquery.validate.js"></script>
<script src="<?php  echo base_url();?>assets/js/developercustom.js"></script>
 <link rel="stylesheet" href="<?php  echo base_url();?>/assets/css/developer_custom.css">
</body>
</html>
<script>
// assumes you're using jQuery
$(document).ready(function() {
	
//$('.confirm-div').hide();
<?php if($this->session->flashdata('message')){ ?>

$('#flash-message').html('<div class="alert alert-info alert-dismissable fade in col-md-6 confirm-div"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><?php echo $this->session->flashdata('message'); ?></div>').show();

<?php } ?>
});
</script>