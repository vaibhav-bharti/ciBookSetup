<?php $this->load->view('template/sendagain_header');  ?>
<div class="content-container">
  <div class="container">
  <div class="wrapper"> 
	<div class="row">
	<div class="col-md-8"> 

	<div class="left-side"> 
	<h2 class="login-tittle"> The Social Network for 
	Making <span> new friends </span> </h2>
	<h4> Millions of people are having fun and making new friends on <br>
	<strong> Sendersbook </strong>  every day. You can too! </h4>
	<div>
	<div class="main-features-box">
	<div class="col-md-6 feature">
	<img src="<?php  echo base_url();?>/assets/images/friends-icon.png">
	<h3> Make
	friends</h3>
	 </div>
	<div class="col-md-6 feature"> 
	<img src="<?php echo base_url();?>/assets/images/like-icon.png">
	<h3> Like </h3>
	</div>

	<div class="col-md-6 feature">
	<img src="<?php echo base_url();?>/assets/images/newsfeedicon.png">
	<h3> News Feed</h3>
	 </div>
	<div class="col-md-6 feature"> 
	<img src="<?php echo base_url();?>/assets/images/comment-icon.png">
	<h3> Comment</h3>
	</div>
	</div>


	 </div>
	 

	</div>
	</div>
	<div class="col-md-4"> 

	<div class="sign-up-box">
	<div class="signup-box-tittle text-center">
	<h3>Verify Your Account </h3>
	 </div>
	<div class="sign-up-box-content">
	<?php	$email = array(
	'name'	=> 'email',
	'id'	=> 'email',
	'class'=>'form-control',
	'value'	=> set_value('email'),
	'maxlength'	=> 80,
	'size'	=> 30,
	'placeholder'	=> 'Enter Email Id',
);
?>
<?php echo form_open($this->uri->uri_string()); ?>

		<div class="input-group">
		<?php echo form_label('Email Address', $email['id'],["style"=>"color:white"]); ?>
		<?php echo form_input($email); ?>
		</div>
		<span  class="help-block"><?php echo form_error($email['name']); ?><?php echo isset($errors[$email['name']])?$errors[$email['name']]:''; ?></span>

<?php echo form_submit('send', 'Send',['class'=>"btn btn-lg btn-primary "]); ?>
<?php echo form_close(); ?>
	</div>
	 </div>

	</div>
	</div>
	</div>

	  </div>
	  </div>
<?php $this->load->view('template/footer'); ?>