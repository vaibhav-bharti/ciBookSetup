<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$email = array(
	'name'	=> 'email',
	'id'	=> 'email',
	'value'	=> set_value('email'),
	'maxlength'	=> 80,
	'size'	=> 30,
);
$password = array(
	'name'	=> 'password',
	'id'	=> 'password',
	'value' => set_value('password'),
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
);
$confirm_password = array(
	'name'	=> 'confirm_password',
	'id'	=> 'confirm_password',
	'value' => set_value('confirm_password'),
	'maxlength'	=> $this->config->item('password_max_length', 'tank_auth'),
	'size'	=> 30,
);
?>

<?php $this->load->view('template/header'); ?>
<div class="content-container">
  <div class="container">
  <div class="wrapper"> 
	<div class="row">
	<div class="col-md-8"> 

	<div class="left-side"> 
	<h2 class="login-tittle"> The Social Network for 
	Making <span> new friends </span> </h2>
	<h4> Millions of people are having fun and making new friends on <br>
	<strong> Sendersbook </strong>  every day. You can too! </h4>
	<div>
	<div class="main-features-box">
	<div class="col-md-6 feature">
	<img src="<?php  echo base_url();?>/assets/images/friends-icon.png">
	<h3> Make
	friends</h3>
	 </div>
	<div class="col-md-6 feature"> 
	<img src="<?php echo base_url();?>/assets/images/like-icon.png">
	<h3> Like </h3>
	</div>

	<div class="col-md-6 feature">
	<img src="<?php echo base_url();?>/assets/images/newsfeedicon.png">
	<h3> News Feed</h3>
	 </div>
	<div class="col-md-6 feature"> 
	<img src="<?php echo base_url();?>/assets/images/comment-icon.png">
	<h3> Comment</h3>
	</div>
	</div>


	 </div>
	 

	</div>
	</div>
	<div class="col-md-4"> 

	<div class="sign-up-box">
	<div class="signup-box-tittle text-center">
	<h3>create an account </h3>
	 </div>
	<div class="sign-up-box-content">
	 <form class="loginForm   rightsideform" id="registration" name="registration" action="<?php echo base_url(); ?>home/register" autocomplete="off" method="POST">
						<div class="input-group">
							<input type="text" class="form-control" name="email" id-"login_email" placeholder="Email Address">
						</div>
						
						<span class="help-block"><?php echo form_error($email['name']); ?><?php echo isset($errors[$email['name']])?$errors[$email['name']]:''; ?></span>
											
						<div class="input-group">
							
							<input  type="password" class="form-control" name="password"  id="pin_password" placeholder="Password">
						</div>
						<span class="help-block"><?php echo form_error($password['name']); ?></span>
						
						<div class="input-group">
							<input  type="password" class="form-control" name="confirm_password"  id="verify_pin_password" placeholder="Retype Password">
						</div>
						
						<span class="help-block"><?php echo form_error($confirm_password['name']); ?></span><div style=" margin-top:5px;" class="terms-conditions" >
											<label>
											  <input id="term-conditon" type="checkbox" name="policy" value="1"> I agree to the <span> Terms and Conditions. </span>
											</label>
										  </div>

						<p><button class="btn btn-lg btn-primary btn-block sign-upbutton" type="submit">SIGN UP</button></p>
					</form>
		
		</div>
	 </div>

	</div>
	</div>
	</div>

	  </div>
	  </div>
	  


<?php $this->load->view('template/footer'); ?>

<script type="text/javascript">

// validate Login form on keyup and submit
$("#loginform").validate({
			errorClass: "my-login-error-class",
			validClass: "my-login-valid-class",
			
			errorPlacement: function(error, element) {
				
				console.log(error.text());
				element.parent().next(".my-login-error-class").text(error.text());
			
				
			},
			success: function(element){
				
				  element.parent().next(".my-login-error-class").text('');                    
			},
			rules: {
				login: {
						required: true,
						email:true
						},
				password: "required"	
			},
			messages: {
				login: {
					required: "Please provide an email Id.",
					email: "Email is not valid"
				},
				password: "Please provide a password",
				
				}
		});
	// validate signup form on keyup and submit
	
		$("#registration").validate({
			errorClass: "my-error-class",
			validClass: "my-valid-class",
			success: function(element){
				
				  element.parent().next(".help-block").text('');                    
			},
			rules: {
				email: {
						required: true,
						email:true
						},
				password: "required",
				confirm_password: {
					required: true,
					minlength: 5,
					equalTo: "#pin_password"
				},
				policy:"required"
			},
			messages: {
				email: {
					required: "Please provide an email Id.",
					email: "Email is not valid"
				},
				password: "Please provide a password",
				confirm_password:{
					required: "Please provide a password",
					equalTo: "Please enter the same password as above"
				},
				policy:"Please accept our policy"
			}
		});



</script>

<style>
	.my-error-class {
    color:#cc99ff;  /* red */
}
.my-valid-class,.my-login-valid-class {
    color:#4CAF50; /* green */
}
</style>