<?php $this->load->view('template/header2');
 ?>
 <div class="content-container">
  <div class="container">
  
  <div class="wrapper">
<div id="stepwizardf" class="stepwizard col-md-offset-3 page-section-heading hidden-xs">
    <div class="stepwizard-row setup-panel">
      <div class="stepwizard-step">
        <a href="#step-1" type="button" class="btn  step-form-btn  btn-active">Step 1</a>
      </div>
      <div class="stepwizard-step">
        <a href="#step-2" type="button" class="btn  step-form-btn btn-deactive " disabled="disabled">Step 2</a>
      </div>
      <div class="stepwizard-step">
        <a href="#step-3" type="button" class="btn step-form-btn  btn-deactive" disabled="disabled">Step 3</a>
      </div>
    </div>
  </div>
<div class="col-xs-6 col-md-3"> 
 <div class="row">
<div class="profile-left-sec full-height-container">
<div class="panel-body text-center" id="pp-container">
<?php $src= base_url()."/assets/images/avtar.jpg";
 if(!empty($userRow['profile_pic'])){$src=base_url().$userRow['profile_pic'];} ?>
<img src="<?php echo $src; ?>" class="profile-image img-circle"  id="profile-img-tag">
<i class="fa fa-camera" id="browse-icon" aria-hidden="true"></i>


 </div>
</div>
</div>
</div>

<div class="col-xs-12 col-md-9">
<div class="row">
<div class="panel panel-default">

<div class="panel-body full-height-container">
  <?php
$firstname = array(
	'name'	=> 'first_name',
	'id'	=> 'first_name',
	'value' => @$userRow['first_name'],
	'maxlength'	=> 80,
	'size'	=> 30,
	'class'	=> "form-control",
	'placeholder'	=> 'Enter First Name',
);
$lastname = array(
	'name'	=> 'last_name',
	'id'	=> 'last_name',
	'value' => $userRow['last_name'],
	'maxlength'	=> 80,
	'size'	=> 30,
	'class'	=> "form-control",
	'placeholder'	=> 'Enter Last Name',
);
$date_of_birth = array(
	'name'	=> 'date_of_birth',
	'id'	=> 'date_of_birth','class'	=> "form-control",
	'value' => $userRow['date_of_birth'],
	'placeholder'	=> '00/00/0000 00:00 AM/PM',
	
);

$attributes=array('class' => 'proset1', 'id' => 'proset1','name'=>'proset1');
// if(!empty($userRow)){print_r($userRow);die;}
?>
<style>
.help-block,.my-proset1-error-class{color:red !important;}
.help-block{font-weight: bold;}
.my-proset1-valid-class{color:#4CAF50 !important;}
</style>
 <?php echo form_open_multipart($this->uri->uri_string(),$attributes); ?>
    <div class="setup-content" id="step-1">
	 <h3>Basic Information</h3>
		  <hr>
      <div class="col-xs-12 col-md-8 col-sm-8">
        <div class="col-md-12">
          <input type="file" id="profile_pic" name="profile_pic">
          <div class="form-group">
            <label class="control-label">First Name</label>
           
			<?php echo form_input($firstname); ?>
          </div>
		  <span class="help-block"></span>
          <div class="form-group">
            <label class="control-label">Last Name</label>
            <?php echo form_input($lastname); ?>
          </div>
          <span class="help-block"></span>
		    <div class="form-group">
		
                        <label for="datepicker">Datepicker</label>  
						
						<div class='input-group date' id='datetimepicker1'>
							 <?php echo form_input($date_of_birth); ?>
							<span class="input-group-addon">
								<span class="glyphicon glyphicon-calendar"></span>
							</span>
						</div>
						
            </div>
			<span class="help-block"></span>
		<div class="form-group">
		<label for="datepicker">Gender</label>
		<div class="input-group">
					<div class="radio radio-inline">
						<?php echo form_radio('gender', 'male',set_value('gender',$userRow['gender']) == 'male' ? "checked" : "",["id"=>"inlineRadio1"]); ?> 
                        <label for="inlineRadio1">Male</label>
                    </div>
					<div class="radio radio-inline">
                       <?php echo form_radio('gender', 'female', set_value('gender',$userRow['gender']) == 'female' ? "checked" : "",["id"=>"inlineRadio2"]); ?>
                        <label for="inlineRadio2">Female</label>
                    </div>
		</div>
		<span class="help-block"></span>
	    </div>
			<?php echo form_submit('submit', 'Save & Continue',['class'=>'btn btn-primary  btn-lg fwd-btn']); ?>
			<?php echo form_close(); ?>		  
         
        </div>
      </div>
    </div>
    <div class=" setup-content" id="step-2">
      <div class="col-xs-12 col-md-8 col-sm-8">
        <div class="col-md-12">
          <h3> Contact Information</h3>
		  <hr>
          <div class="form-group">
            <label class="control-label">Secondary Email </label>
            <input maxlength="200" type="email" required="required" class="form-control" placeholder="Secondary Email " />
          </div>
          <div class="form-group">
            <label class="control-label">Phone Number</label>
            <input maxlength="200" type="text" required="required" class="form-control" placeholder="Phone Number"  onkeypress="return isNumber(event)" /> 
          </div>	 
		   <button class="btn btn-primary nextBtn bck-btn" type="button" >Back</button>
          <button class="btn btn-primary nextBtn btn-lg fwd-btn" type="button">Save & Continue</button>
	
        </div>
      </div>
    </div>
    <div class=" setup-content" id="step-3">
      <div class="col-xs-12 col-md-8 col-sm-8">
        <div class="col-md-12">
          <h3> Other Information </h3>
		  <hr>
		    <div class="form-group">
 <label for="datepicker">Martial Status</label>
 <div class="input-group">
<div class="radio radio-inline">

                        <input id="inlineRadio1" value="option1" name="radioInline" checked type="radio" required="required" >
                        <label for="inlineRadio1">Married</label>
                      </div>
					  <div class="radio radio-inline">
                        <input id="inlineRadio2" value="option2" name="radioInline" type="radio" required="required">
                        <label for="inlineRadio2">Unmarried</label>
                      </div>
					  </div>
					  </div>
					  
					  <div class="form-group"> 
					   <label for="State">Select State</label>
					  <select class="form-control">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                  </select>
					  
					  </div>
					  
					   <div class="form-group"> 
					   <label for="city">Current City</label>
					  <select class="form-control">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                  </select>
		
					  
					  </div>
					  
					    <div class="form-group"> 
					   <label for="State">About me</label>
					<textarea class="form-control" placeholer="Message">
                                      </textarea>
					  
					  </div>
		   <button class="btn btn-primary nextBtn  bck-btn" type="button" >Back</button>
          <button class="btn btn-success btn-lg fwd-btn" type="submit"  formaction="myprofile.html" >Save & Continue</button>
        </div>
      </div>
    </div>
  </form>


					  </div>
					  </div>
					  
</div>
</div>

</div>
</div>

  </div>
  </div>
  
</div>



<?php $this->load->view('template/footer'); ?>



<script type="text/javascript">
  $(document).ready(function () {
	 
  var navListItems = $('div.setup-panel div a'),
          allWells = $('.setup-content'),
          allNextBtn = $('.nextBtn');

  allWells.hide();
 

  navListItems.click(function (e) {
      e.preventDefault();
      var $target = $($(this).attr('href')),
              $item = $(this);

      if (!$item.hasClass('disabled')) {
          navListItems.removeClass('btn-active').addClass('btn-deactive');
          $item.addClass('btn-active');
          allWells.hide();
          $target.show();
          $target.find('input:eq(0)').focus();
      }
  });

  allNextBtn.click(function(){
      var curStep = $(this).closest(".setup-content"),
          curStepBtn = curStep.attr("id"),
          nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
          curInputs = curStep.find("input[type='text'],input[type='url'], input[type='email']"),
          isValid = true;

      $(".form-group").removeClass("has-error");
      for(var i=0; i<curInputs.length; i++){
          if (!curInputs[i].validity.valid){
              isValid = false;
              $(curInputs[i]).closest(".form-group").addClass("has-error");
          }
      }

      if (isValid)
          nextStepWizard.removeAttr('disabled').trigger('click');
  });

  $('div.setup-panel div a.btn-active').trigger('click');
});
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

    		function DropDown(el) {
				this.dd = el;
				this.placeholder = this.dd.children('span');
				this.opts = this.dd.find('.dropdown a');
				this.val = '';
				this.index = -1;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						return false;
					});

					obj.opts.on('click',function(){
						var opt = $(this);
						obj.val = opt.text();
						obj.index = opt.index();
						obj.placeholder.text(obj.val);
					});
				},
				getValue : function() {
					return this.val;
				},
				getIndex : function() {
					return this.index;
				}
			}

			$(function() {

				var dd = new DropDown( $('#dd') );



			});
  </script>
  
  <style>
	.profile-image{
	height: 185px;
	width: 185px;
	}
  </style>
</body>
</html>