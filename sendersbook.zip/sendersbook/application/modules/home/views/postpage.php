<?php $this->load->view('template/header2'); ?>
<div class="profile-container">
  <div class="container">
    <div class="row">
      <div id="profile" class="banner">
        <div class="banner-info">
          <div class="container">
            <div class="col-md-4 header-left text-center"> <img src="images/user.jpg" alt=""> </div>
            <div class="col-md-8 header-right">
              <h1>Deep Buggran</h1>
              <ul class="address list-unstyled">
                <li>
                  <ul class="address-text list-unstyled">
                    <li><b>Email</b></li>
                    <li>user@mail.com</li>
                  </ul>
                </li>
                <li>
                  <ul class="address-text list-unstyled">
                    <li><b>Age </b></li>
                    <li>23</li>
                  </ul>
                </li>
                <li>
                  <ul class="address-text list-unstyled">
                    <li><b>Gender </b></li>
                    <li>Male</li>
                  </ul>
                </li>
              </ul>
            </div>
            <div class="clearfix"> </div>
          </div>
        </div>
      </div>
      <!--Profile-cover-top-->
      
      <div class="post-page" id="mywall">
        <div class="col-md-12 active">
		 <div class="newsfeed">
            <div class="col-md-12 item" style="position: absolute; left: 0px; top: 0px;">
              <div class="row">
                <div class="timeline-block">
                  <div class="panel panel-default share clearfix-xs">
                    <div class="panel-body">
                      <textarea name="status" class="form-control share-text" rows="3" placeholder="Share your status..."></textarea>
                    </div>
                    <div class="panel-footer share-buttons"> <a href="#"><i class="fa fa-photo"></i></a>
                      <button type="submit" class="btn btn-primary btn-xs pull-right display-none" href="#">Post <i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>
                    </div>
                  </div>
                </div>
                <div class="timeline-block">
                  <a  href="#" class="panel-heading head-notification text-center"> You have 2 Pending Posts for approval. </a>
                  <h4>NEWSFEED </h4>
                  <div class="single-post">
                    <div class="media user-meta">
                      <div class="media-left"> <a href=""> <img src="images/people/50/guy-2.jpg" class="media-object">
                        <h4> James Bond</h4>
                        </a> </div>
                      <div class="media-right"> <a href="#" class="pull-right text-muted"><i class="icon-reply-all-fill fa fa-2x "></i></a> <span class="pull-right">on 15th January, 2014</span> </div>
                    </div>
                    <div class="panel-default">
                      <div class="panel-body">
                        <div class="col-md-4 post-image"> <img src="images/postimage1.jpg"  class="img-responsive img-thumbnail" ></div>
                        <div class="col-md-8 post-descripition">
                          <p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire On the other hand, </p>
                          <a href="#"> read more </a> </div>
                      </div>
                      <div class="view-all-comments"> <a href="#" id="myBtn"> <i class="fa fa-heart" aria-hidden="true"> </i> 800 Likes </a> <a href="#"> <i class="fa fa-comments-o"></i> 10 comments </a> <a href="#">
                        <p class="pull-right">View all Comments</p>
                        </a> </div>
                      <ul class="comments">
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/guy-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Bill D.</a> <span>I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth</span>
                            <div class="comment-date">21st September</div>
                          </div>
                        </li>
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/woman-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Mary</a> <span>But I must explain to you how all this mistaken idea of denouncing pleasure</span>
                            <div class="comment-date">2 days</div>
                          </div>
                        </li>
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/guy-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Bill D.</a> <span>What time did it finish?</span>
                            <div class="comment-date">14 min</div>
                          </div>
                        </li>
                        <li class="comment-form">
                          <div class=""> <span class="pull-right"> <a href="" class=""><i class="fa fa-paper-plane" aria-hidden="true"></i></a> </span>
                            <input class="form-control" type="text">
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="single-post">
                    <div class="media user-meta">
                      <div class="media-left"> <a href=""> <img src="images/people/50/woman-3.jpg" class="media-object">
                        <h4> James Bond</h4>
                        </a> </div>
                      <div class="media-right"> <a href="#" class="pull-right text-muted"><i class="icon-reply-all-fill fa fa-2x "></i></a> <span class="pull-right">on 15th January, 2014</span> </div>
                    </div>
                    <div class="panel-default">
                      <div class="panel-body">
                        <div class="col-md-12 post-image"> <img src="images/postimage2.jpg"  class="img-responsive img-thumbnail" ></div>
                      </div>
                      <div class="view-all-comments"> <a href="#"> <i class="fa fa-heart active" aria-hidden="true"> </i> 800 Likes </a> <a href="#"> <i class="fa fa-comments-o"></i> 10 comments </a> <a href="#">
                        <p class="pull-right">View all Comments</p>
                        </a> </div>
                      <ul class="comments">
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/woman-3.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Bill D.</a> <span>I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth</span>
                            <div class="comment-date">21st September</div>
                          </div>
                        </li>
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/woman-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Mary</a> <span>But I must explain to you how all this mistaken idea of denouncing pleasure</span>
                            <div class="comment-date">2 days</div>
                          </div>
                        </li>
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/woman-3.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Bill D.</a> <span>What time did it finish?</span>
                            <div class="comment-date">14 min</div>
                          </div>
                        </li>
                        <li class="comment-form">
                          <div class=""> <span class="pull-right"> <a href="" class=""><i class="fa fa-paper-plane" aria-hidden="true"></i></a> </span>
                            <input class="form-control" type="text">
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="single-post">
                    <div class="media user-meta">
                      <div class="media-left"> <a href=""> <img src="images/people/50/woman-7.jpg" class="media-object">
                        <h4> James Bond</h4>
                        </a> </div>
                      <div class="media-right"> <a href="#" class="pull-right text-muted"><i class="icon-reply-all-fill fa fa-2x "></i></a> <span class="pull-right">on 15th January, 2014</span> </div>
                    </div>
                    <div class="panel-default">
                      <div class="panel-body">
                        <div class="col-md-12 post-descripition">
                          <p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire </p>
                        </div>
                      </div>
                      <div class="view-all-comments"> <a href="#"> <i class="fa fa-heart" aria-hidden="true"> </i> 800 Likes </a> <a href="#"> <i class="fa fa-comments-o"></i> 10 comments </a> <a href="#">
                        <p class="pull-right">View all Comments</p>
                        </a> </div>
                      <ul class="comments">
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/guy-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Bill D.</a> <span>I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth</span>
                            <div class="comment-date">21st September</div>
                          </div>
                        </li>
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/woman-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Mary</a> <span>But I must explain to you how all this mistaken idea of denouncing pleasure</span>
                            <div class="comment-date">2 days</div>
                          </div>
                        </li>
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/guy-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Bill D.</a> <span>What time did it finish?</span>
                            <div class="comment-date">14 min</div>
                          </div>
                        </li>
                        <li class="comment-form">
                          <div class=""> <span class="pull-right"> <a href="" class=""><i class="fa fa-paper-plane" aria-hidden="true"></i></a> </span>
                            <input class="form-control" type="text">
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="single-post">
                    <div class="media user-meta">
                      <div class="media-left"> <a href=""> <img src="images/people/50/guy-2.jpg" class="media-object">
                        <h4> James Bond</h4>
                        </a> </div>
                      <div class="media-right"> <a href="#" class="pull-right text-muted"><i class="icon-reply-all-fill fa fa-2x "></i></a> <span class="pull-right">on 15th January, 2014</span> </div>
                    </div>
                    <div class="panel-default">
                      <div class="panel-body">
                        <div class="col-md-4 post-image"> <img src="images/postimage1.jpg"  class="img-responsive img-thumbnail" ></div>
                        <div class="col-md-8 post-descripition">
                          <p>On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire On the other hand, </p>
                          <a href="#"> read more </a> </div>
                      </div>
                      <div class="view-all-comments"> <a href="#"> <i class="fa fa-heart" aria-hidden="true"> </i> 800 Likes </a> <a href="#"> <i class="fa fa-comments-o"></i> 10 comments </a> <a href="#">
                        <p class="pull-right">View all Comments</p>
                        </a> </div>
                      <ul class="comments">
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/guy-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Bill D.</a> <span>I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth</span>
                            <div class="comment-date">21st September</div>
                          </div>
                        </li>
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/woman-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Mary</a> <span>But I must explain to you how all this mistaken idea of denouncing pleasure</span>
                            <div class="comment-date">2 days</div>
                          </div>
                        </li>
                        <li class="media">
                          <div class="media-left"> <a href=""> <img src="images/people/50/guy-5.jpg" class="media-object"> </a> </div>
                          <div class="media-body">
                            <div class="pull-right dropdown" data-show-hover="li" style="display: none;"> <a href="#" data-toggle="dropdown" class="toggle-button"> <i class="fa fa-pencil"></i> </a>
                              <ul class="dropdown-menu" role="menu">
                                <li><a href="#">Edit</a></li>
                                <li><a href="#">Delete</a></li>
                              </ul>
                            </div>
                            <a href="" class="comment-author pull-left">Bill D.</a> <span>What time did it finish?</span>
                            <div class="comment-date">14 min</div>
                          </div>
                        </li>
                        <li class="comment-form">
                          <div class=""> <span class="pull-right"> <a href="" class=""><i class="fa fa-paper-plane" aria-hidden="true"></i></a> </span>
                            <input class="form-control" type="text">
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="side-menu" id="bodyDiv">
          <div id="sidebar-wrapper" > <a id="menu-toggle" href="#" class="btn btn-primary btn-lg toggle clickme"><i class="fa fa-bars" aria-hidden="true"></i></a>
            <div class="sidebar-nav" > <!-- <a id="menu-close" href="#" class="btn btn-default btn-lg pull-right toggle"><i class="fa fa-times" aria-hidden="true"></i>  </a> -->
              <div class="chat-section" >
                <div class="sidebar sidebar-chat right sidebar-size-2 sidebar-offset-0 chat-skin-dark sidebar-visible-mobile st-effect-1" id="sidebar-chat scrollbox3" style="display: block;">
                  <div class="split-vertical">
                    <div class="chat-section-heading">
                      <h4>FRIEND LIST </h4>
                      <span> View All</span></div>
                    <div class="chat-search">
                      <input class="form-control" placeholder="Search" type="text">
                    </div>
                    <div class="split-vertical-body">
                      <div class="split-vertical-cell">
                        <div data-scrollable="" style="overflow-y: hidden;" tabindex="0">
                          <ul class="chat-contacts">
                            <li class="" data-user-id="1"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/guy-6.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Jonathan S.</div>
                                  <small>"Free Today"</small> </div>
                              </div>
                              </a> </li>
                            <li class=" away" data-user-id="2"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/woman-5.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Mary A.</div>
                                  <small>"Feeling Groovy"</small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="3"> <a href="#">
                              <div class="media">
                                <div class="pull-left "> <span class="status"></span> <img src="images/people/110/guy-3.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Adrian D.</div>
                                  <small>Busy</small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="4"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <img src="images/people/110/woman-6.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Michelle S.</div>
                                  <small></small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="5"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <img src="images/people/110/woman-7.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Daniele A.</div>
                                  <small></small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="6"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/guy-4.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Jake F.</div>
                                  <small>Busy</small> </div>
                              </div>
                              </a> </li>
                            <li class=" away" data-user-id="7"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/woman-6.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Jane A.</div>
                                  <small>"Custom Status"</small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="8"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/woman-8.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Sabine J.</div>
                                  <small>" right now"</small> </div>
                              </div>
                              </a> </li>
                            <li class=" away" data-user-id="9"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/woman-9.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Danny B.</div>
                                  <small>Be Right Back</small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="10"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/woman-8.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Elise J.</div>
                                  <small>My Status</small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="11"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/guy-3.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">John J.</div>
                                  <small>My Status #1</small> </div>
                              </div>
                              </a> </li>
							  <li class=" away" data-user-id="9"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/woman-9.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Danny B.</div>
                                  <small>Be Right Back</small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="10"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/woman-8.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">Elise J.</div>
                                  <small>My Status</small> </div>
                              </div>
                              </a> </li>
                            <li class="" data-user-id="11"> <a href="#">
                              <div class="media">
                                <div class="pull-left"> <span class="status"></span> <img src="images/people/110/guy-3.jpg" class="img-circle" width="40"> </div>
                                <div class="media-body">
                                  <div class="contact-name">John J.</div>
                                  <small>My Status #1</small> </div>
                              </div>
                              </a> </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div id="ascrail2000" class="nicescroll-rails" style="width: 5px; z-index: 2; cursor: default; position: absolute; top: 87px; left: 195px; height: 459px; display: block; opacity: 0;">
                    <div style="position: relative; top: 0px; float: right; width: 5px; height: 274px; background-color: rgb(22, 174, 159); border: 0px none; background-clip: padding-box; border-radius: 5px;"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- The Modal -->
<div id="myModal" class="modal"> 
  
  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header"> <span class="close">&times;</span>
      <h4>800 People Likes the Post</h4>
    </div>
    <div class="modal-body">
      <div class="user-friend-list">
        <ul>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
          <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
          <div id="demo" class="collapse">
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/guy-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p> </li>
            <li> <a href="#"> <img src="images/people/50/woman-3.jpg" alt="people" class="img-circle"> <span> Friend1 Name</span> </a>  <p class="pull-right like-meta-time">on 25 january 2:49 am </p></li>
          </div>
        </ul>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#demo">See More</button>
    </div>
  </div>
</div>
<?php $this->load->view('template/footer'); ?>