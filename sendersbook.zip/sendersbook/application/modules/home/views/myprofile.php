<?php $this->load->view('template/header2'); ?>
 <div class="profile-container">

      <div class="container">
<div class="row">
   <div id="profile" class="banner">

<div class="banner-info">
			<div class="container">
				<div class="col-md-4 header-left text-center">
					<img src="images/user.jpg" alt="">
				</div>
				<div class="col-md-8 header-right">
					
					<h1>Deep Buggran</h1>
					
					<ul class="address list-unstyled">
						<li>
							<ul class="address-text list-unstyled">
								<li><b>Email</b></li>
								<li>user@mail.com</li>
							</ul>
						</li>
						<li>
							<ul class="address-text list-unstyled">
								<li><b>Age </b></li>
								<li>23</li>
							</ul>
						</li>
						<li>
							<ul class="address-text list-unstyled">
								<li><b>Gender </b></li>
								<li>Male</li>
							</ul>
						</li>
						
						
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
        
        </div>
        
		<div class="profile-info">
		<div class="pull-right">
		<a href="#" class="btn btn-info blue-btn clickme" role="button" id="hideshow" value='hide/show'> <i class="fa fa-pencil" aria-hidden="true"></i> Edit Profile </a>
		</div>
		<div class="about-me" id="about">

		<div class="my-contact-info">
		<div class="col-md-6">
<h2> Contact Information</h2>
<form class="form-horizontal">
<fieldset>



<!-- Text input-->
<div class="form-group">
  <label class="col-md-12 control-label" for="textinput">Secodary Email




</label>  
  <div class="col-md-12">
  <!-- <input id="textinput" name="textinput" type="text" placeholder="trade show name" class="form-control input-md content">-->
  <p class="my-info"> xyz@domin.com </p>
    
  </div>
  
</div>
<!-- Text input-->
<div class="form-group">
  <label class="col-md-12 control-label" for="textinput">Phone</label>  
  <div class="col-md-12">
  <!-- <input id="textinput" name="textinput" type="text" placeholder="trade show name" class="form-control input-md content "> -->
  <p class="my-info"> +1 589 8988 595</p>
    
  </div>
</div>

</fieldset>
</form>
</div>
	<div class="col-md-6">
<h2> Other Information</h2>
<form class="form-horizontal">
<fieldset>



<!-- Text input-->
<div class="form-group">
  <label class="col-md-12 control-label" for="textinput">Martial Status








</label>  
  <div class="col-md-12">
  <!-- <input id="textinput" name="textinput" type="text" placeholder="trade show name" class="form-control input-md content">-->
  <p class="my-info"> Unmarried</p>
    
  </div>
  
</div>
<!-- Text input-->
<div class="form-group">
  <label class="col-md-12 control-label" for="textinput">Current City</label>  
  <div class="col-md-12">
  <!-- <input id="textinput" name="textinput" type="text" placeholder="trade show name" class="form-control input-md content "> -->
  <p class="my-info"> Birmingham</p>
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-12 control-label" for="textinput">Current State</label>  
  <div class="col-md-12">
  <!-- <input id="textinput" name="textinput" type="text" placeholder="trade show name" class="form-control input-md content "> -->
  <p class="my-info"> Alabama</p>
    
  </div>
</div>

</fieldset>
</form>
</div>
	<div class="col-md-12">
<h2> About me</h2>
<form class="form-horizontal">
<fieldset>



<!-- Text input-->
<div class="form-group">
  
  <div class="col-md-12">
  <!-- <input id="textinput" name="textinput" type="text" placeholder="trade show name" class="form-control input-md content">-->
  <p class="my-info"> But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itselflt</p>
  <p class="my-info">The actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itselflt </p>
    
  </div>
  
</div>



</fieldset>
</form>
</div>
</div>
</div>
</div>
</div> 
</div> 
</div>
<?php $this->load->view('template/footer'); ?>
