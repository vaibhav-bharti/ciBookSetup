$(document).ready(function () {
	
	$("#profile_pic").hide();
	$("#browse-icon").on("click",function(){
		 $("#profile_pic").click();
		
	});
	
	
	$("#profile-img-tag").hover(function() {
		$(this).css('border','1px solid #3BAFD5');
	}, function() {
		$(this).css('border','');
	});
	
	$("#browse-icon").hover(function() {
		$(this).css('cursor','pointer');
		$(this).attr('title', 'change the profile pic.');
	}, function() {
		$(this).css('cursor','auto');
	});
	
   /**
	 *FUNCTION FOR IMAGE PREVIEW
	 *
	 **/
	function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();
		var form_data = new FormData();  
		form_data.append("profile_pic", input.files[0]) ;
        reader.onload = function (e) {
            $('#profile-img-tag').attr('src', e.target.result);
        }
		console.log(form_data);
		$.ajax({
                url: baseUrl+"home/uploadpp1",
                data: form_data,             // Setting the data attribute of ajax with file_data
                processData: false,
				contentType: false,
				type: 'post',
				success:function(data){console.log(data);}
       });
        reader.readAsDataURL(input.files[0]);
    }
}
function startUpload(input){
  var file_data = input.files[0];   // Getting the properties of file from file field
	var form_data = new FormData();                  // Creating object of FormData class
	//form_data.append("file", file_data) ;             // Appending parameter named file with properties of file_field to form_data 
	//form_data.append("user_id", 123);                 // Adding extra parameters to form_data
	//console.log(file_data);
	//console.log(form_data);
	$.ajax({
                url: baseUrl+"home/uploadpp1",
                data: form_data,                         // Setting the data attribute of ajax with file_data
                type: 'post',
				success:function(data){console.log(data);}
       });
  
}
	$("#profile_pic").change(function(){
		readURL(this); 
		// startUpload(this);
	});
	/**
	 *Date picker
	 **/
	$(function () {
                $('#datetimepicker').datetimepicker();
                $('#datetimepicker1').datetimepicker();
            });
			
	/**
	 *Validate the profile setup form 1
	 **/
		jQuery.validator.addMethod("lettersonly", function(value, element) {
		return this.optional(element) || /^[a-z]+$/i.test(value);
		}, "Letters only please");
	$("#proset1").validate({
			errorClass: "my-proset1-error-class",
			validClass: "my-proset1-valid-class",
			errorPlacement: function(error, element) {
			if (element.attr("name") == "gender" || element.attr("name") == "date_of_birth")
				{
					element.parent().parent().next(".help-block").text(error.text());
					return false;
				}
				else
				{
					error.insertAfter(element);
				}
			},
			success: function(element){
				
				  element.parent().next(".help-block").text('');                    
			},
			rules: {
				first_name: {
						required: true,lettersonly: true
						},					
				last_name: {
						required: true,lettersonly: true
						},	
				date_of_birth: "required",	
				gender: "required",	
			},
			messages: {
				first_name: {
					required: "Please provide First Name."
					
				},
				last_name: {
					required: "Please provide Last Name."
					
				},
				
				}
		});
});

